describe('Auth page', function () {
	it('should type login and pass',function (){
		//Authorisation
		browser.get('http://team.binary-studio.com');

		var el = element;
		var login = el(by.model('authLoginCtrl.user.email')).click();
		var pass = el(by.model('authLoginCtrl.user.password')).click();

		login.sendKeys('tester_e@example.com');
		pass.sendKeys('123456');

		el(by.css('.btn','Log in')).click(); //check selector csscontaintesxt

		expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/company');
	});

	describe('Company', function(){
		it('should select "Search" and type "Binary"', function(){

			var el = element;

			var search = el(by.model('newsCtrl.newsFilter')).click();
			search.sendKeys('Binary');

			let list = el.all(by.css('.news-title-2'));
			expect(list.count()).toBe(4);
		});
	});	

	describe('Sandbox', function(){
		it('should select input, write text, and create post', function(){

			var el = element;

			browser.findElement(by.cssContainingText('.md-tab', 'Sandbox')).click();
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/sandbox');

			var field = el(by.id('ui-tinymce-0_ifr')).click();
			field.sendKeys("This is a test post");
			el(by.cssContainingText('.md-button', 'Create post')).click();

			let list = el.all(by.css('.news-body-2')).first();
			expect(list.getText()).toBe('This is a test post');
		});
	});

	describe('Sandbox', function (){
		it('should find and delete personal post', function(){

			var el = element

			browser.findElement(by.cssContainingText('.md-tab', 'Sandbox')).click();
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/sandbox');
			

			var post = el(by.cssContainingText('.author-2', 'Tester E'));
			el(by.css('.news-2')).click();

			el(by.css('.delete-2')).click();
			el(by.cssContainingText('.ng-binding','Yes')).click();
		});
	});

	describe('Sandbox', function(){
		it('should edit text of the post', function(){

			browser.findElement(by.cssContainingText('.md-tab', 'Sandbox')).click();
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/sandbox');

			var el = element;
			var post = el.all(by.css('.news-body-2')).filter(function(elem, index) {
				return elem.getText().then(function(text) {
					return text === 'This is a test post';
				});
			}).first().click();
			el(by.css('.edit-2')).click();

			// Waits for the element with id 'abc' to be present on the dom.
			var EC = protractor.ExpectedConditions;			
			browser.wait(EC.presenceOf($('.mce-edit-area')), 2000);
			
			$('#ui-tinymce-1_ifr').click().sendKeys(protractor.Key.CONTROL, "a",
				protractor.Key.NULL,
				"This post was edited");
			el(by.cssContainingText('.md-button', 'Save')).click();

			let list = el.all(by.css('.news-body-2')).filter(function(elem, index) {
				return elem.getText().then(function(text) {
					return text === 'This post was edited';
				});
			}).first().click();
			expect(list.getText()).toBe('This post was edited');
		});
	});

	describe('Sandbox', function(){
		it('should edit text of the post and add picture', function(){

			browser.findElement(by.cssContainingText('.md-tab', 'Sandbox')).click();
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/sandbox');

			var el = element;
			var post = el.all(by.css('.news-body-2')).filter(function(elem, index) {
				return elem.getText().then(function(text) {
					return text === 'This is a test post';
				});
			}).first().click();
			el(by.css('.edit-2')).click();

			// Waits for the element with id 'abc' to be present on the dom.
			var EC = protractor.ExpectedConditions;			
			browser.wait(EC.presenceOf($('.mce-edit-area')), 10000);
			
			$('#ui-tinymce-2_ifr').click().sendKeys(protractor.Key.CONTROL, "a",
				protractor.Key.NULL,
				"Looooooolllll");
			var image = $('#mceu_23').click();

			var form = $('.mce-container');
			var EC = protractor.ExpectedConditions;			
			browser.wait(EC.presenceOf($('.mce-container')), 2000);

			$('#mceu_36-inp').click().sendKeys('https://s.dou.ua/storage-files/qad6-3.gif');
			$('#mceu_37').click().sendKeys('Dev VS QA')
			$('.mce-txt').click();

			var EC = protractor.ExpectedConditions;			
			browser.wait(EC.presenceOf($('.mce-edit-area')), 2000);

			el(by.cssContainingText('.md-button', 'Save')).click();

			let list = el.all(by.css('.news-body-2')).filter(function(elem, index) {
				return elem.getText().then(function(text) {
					return text === 'Looooooolllll';
				});
			}).first().click();
			expect(list.getText()).toBe('Looooooolllll');
			
		});
	});

	describe('Sandbox', function(){
		it('should add like to post', function (){
			
			browser.findElement(by.cssContainingText('.md-tab', 'Sandbox')).click();
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/sandbox');

			var el = element;

			el(by.css('.likes-count-2')).click();
			
			let likes = el.all(by.css('.likes-count-2'));
			expect(likes.count()).toBe(10);
		});
	});

	describe('Company', function(){
		it('should open post in a modal window and close it', function(){

			browser.get('http://team.binary-studio.com/#/company');
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/company');

			el = element;

			el(by.cssContainingText('.title-ne', 'Button colors')).click();

			var EC = protractor.ExpectedConditions;
			// Waits for the element with id 'abc' to be present on the dom.
			browser.wait(EC.presenceOf($('.modal-post')), 5000);

			//expect(el(by.css('.news-2 ng-scope'))).toBe(el(by.css('.news-2 ng-scope modal-post')));

			el(by.id('content')).click();

		});
	});

	describe('Company', function(){
	it('should sort posts by year and month', function(){

		browser.get('http://team.binary-studio.com/#/company');
		expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/company');

		el = element;

		year = el(by.id('select_value_label_18')).click();
		el(by.id('select_option_37')).click();
		expect(year.getText()).toBe('2015');

		month = el(by.id('select_value_label_19')).click();
		el(by.id('select_option_33')).click();
		expect(month.getText()).toBe('December');
		});
	});

	describe('Company', function(){
		it('should add the comment a post', function(){

			browser.get('http://team.binary-studio.com/#/company');
			expect(browser.getCurrentUrl()).toBe('http://team.binary-studio.com/#/company');

			el = element;

			el(by.css('.comments-count-2')).click();
			el(by.css('.new-comment-2')).click();
			var EC = protractor.ExpectedConditions;
			// Waits for the element with id 'abc' to be present on the dom.
			browser.wait(EC.presenceOf($('.mce-edit-area')), 2000);
			$('.mce-edit-area').$('#ui-tinymce-0_ifr').click().sendKeys('Awesome');
			$('.mce-edit-area').submit();

			let list = el.all(by.css('.comment-body-2')).filter(function(elem, index) {
				return elem.getText().then(function(text) {
					return text === 'Awesome';
				});
			}).first().click();
			expect(list.getText()).toBe('Awesome');
		});
	});
});