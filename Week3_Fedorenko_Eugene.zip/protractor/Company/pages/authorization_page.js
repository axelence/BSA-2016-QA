require('./company_news_page.js');

var authorization_page = function() {
	
	this.get = function() {
		browser.get("http://team.binary-studio.com/auth");
	};
	
	this.login = function() {
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_a@example.com");
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		element(by.css('button[ng-click="authLoginCtrl.login()"]')).click();
		return require('./company_news_page.js');
	};
	
	this.teardown = function() {
		// element(by.deepCss('.hdr-userprofileAndLogoutBtn .hdr-button')).click();
		browser.wait(protractor.ExpectedConditions.invisibilityOf($('#logOutBtnInBox')), 500000);
		// element(by.id('logOutBtnInBox')).click();
	};
	
};
module.exports = new authorization_page();