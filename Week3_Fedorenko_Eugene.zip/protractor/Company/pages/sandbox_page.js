var confirm_page = function() {
	
	this.getTitleText = function() {
		return element(by.css("h1#title")).getText();
	};
	
};
module.exports = new confirm_page();