require('./sandbox_page.js');

var company_news_page = function() {
	
	this.get = function() {
		browser.get("http://team.binary-studio.com/#/company");
	};
	
	this.likeTestWTeardown = function() {
		// Select first post = div
		// browser.waitForAngular();
		console.log(element(by.xpath('//*[contains(text(),"Button colors")]')));//.getText());
		// console.log("Post title is:  " + element(by.css('.news-2 .ng-scope .news-wrapper .title-ne .ng-binding .ng-scope')).getText());
		
		/* element.all(by.css('div[class="news-wrapper"]')).get(0).then(function(items) {
			console.log("Post title is:  " + element(item[0]).$('span[ng-if="!(newsCtrl.editing._id === news._id)"]').getText());
			 // Save current like count for selected post
			var prevLikesCount = element(item[3]).$('.likes-count-2 go-right.fa fa-thumbs-o-up ng-scope.ng-binding').getText();
			// Add Like
			element(item[3]).$('span[ng-click="newsCtrl.newsLike(news)"]').click();
			// Save like count for selected post after adding Like
			var afterLikesCount = element(item[3]).$('.likes-count-2 go-right.fa fa-thumbs-o-up ng-scope.ng-binding').getText();
			// Check if like count has changed
			expect(prevLikesCount.getText()).not.toBe(afterLikesCount.getText());
			// Teardown
			element(item[3]).$('span[ng-click="newsCtrl.newsLike(news)"]').click(); 
		}); */
	};
	
	this.SimpleCommentTestWTeardown = function() {
		
	};
	
	this.teardown = function() {
		console.log("No teardown available for this test");
	};
	
};
module.exports = new company_news_page();