describe ("Company News - Like the post", function(){
	
	// browser.pause();
	var authorization_page = require('../pages/authorization_page.js');
	
	it ("like the post", function() {
		// var authorization_page = require('../pages/authorization_page.js');
		authorization_page.get();
		var company_news_page = authorization_page.login();
		company_news_page.get();
		company_news_page.likeTestWTeardown();
		authorization_page.teardown();
	});
	
});