var util = require('util')

describe ("jswebapp - Testing the JavaScript zoo site", function(){
	
	beforeEach(function(){
		browser.get("http://www.thetestroom.com/jswebapp/index.html");
	});
	
	xit ("This test will be skipped", function() {
		
	});
	
	var home_page = require('./home_page.js'); // imports JS file
	
	it("pageObject test", function() {
		home_page.enterFieldValue('Subscription');
		var homePageText = home_page.getDynamicText();
		expect(homePageText).toBe('Subscription');
		
		var animal_page = home_page.clickContinue();
		animal_page.selectAnimal(2);
		
		var confirm_page = animal_page.clickContinue();
		expect(confirm_page.getTitleText()).toBe('Thank you');
	});
	
});