Test report (contains all further details):
https://docs.google.com/document/d/1DCnejZuIyaqIoHNKY7p-dVmEXtfY3vPG9CHQImfvTgs/edit?usp=sharing