describe("users should be able to add post to sandbox", function(){
	it ("to fill in user information and login", function(){
		//"to fill in user information and login",
		browser.get("http://team.binary-studio.com/auth/#/");
		//fill in login
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_d@example.com");
		//fill in password
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		//press Login button
		var loginButton = element(by.cssContainingText(".btn", "Log in"));
		loginButton.click()
		console.log("Hello");
	})

	beforeEach(function(){
		//go to Sandbox
		element(by.cssContainingText(".md-tab", "Sandbox")).click();
		console.log("go to sandbox");
	})
	
	it("to create new post in sandbox", function(){
		var text = "new post in sabdbox"
		//create new post
		element(by.xpath('//*[@id="ui-tinymce-0_ifr"]')).sendKeys(text);
		console.log("write text");
		
		element(by.cssContainingText(".md-button", "Create post")).click();
		console.log("press button");
		
	})
	
	it ("to edit post in sandbox", function(){
		var text = "we edit "
		//move mouse to buttons become visible
		browser.actions().mouseMove(element(by.cssContainingText('[ng-click="sboxCtrl.hideModal(news._id)"]', "post in sabdbox"))).perform();
		//press edit button
		expect(element(by.css('[ng-click="newsCtrl.setEditing(news)"]')).isDisplayed()).toBeTruthy();		
		element(by.css('[ng-click="newsCtrl.setEditing(news)"]')).click();
		console.log("press edit button");
		//edit text
		element(by.css('#ui-tinymce-1_ifr')).sendKeys(text);
		console.log("edit text");
		//save edition
		element(by.cssContainingText(".md-button", "Save")).click();
		console.log("save edited post");
	})
	
	
	it ("to delete post in sandbox", function(){
		//move mouse to buttons become visible
		browser.actions().mouseMove(element(by.cssContainingText('[ng-click="sboxCtrl.hideModal(news._id)"]',"post in sabdbox"))).perform();
		console.log("buttons become visibile");
		//press delete button
		expect(element(by.css('[ng-click="newsCtrl.deleteNews(news._id)"]')).isDisplayed()).toBeTruthy();
		element(by.css('[ng-click="newsCtrl.deleteNews(news._id)"]')).click();
		console.log("press delete button");
		//confirm deleting
		expect(element(by.buttonText("Yes")).isDisplayed()).toBeTruthy();
		element(by.buttonText("Yes")).click();
		console.log("confirm deleting");	
	})
	
	describe("users should be able to logout", function(){
	it ("users should be able to logout", function(){
		//afterEach (function(){
			//press on user profile
			
			expect(element(by.id("userProfile")).isDisplayed()).toBeTruthy();
			var logoutBox = browser.findElement(by.id("userProfile"));
			logoutBox.click();
			
			//"to find logout button"
		expect(element(by.id("logOutButton")).isDisplayed()).toBeTruthy();
			var logoutButton = browser.findElement(by.id("logOutButton"));
			logoutButton.click();
			console.log("bye-bye");
	})
})
})