describe("users should be able to like news", function(){
	it ("to fill in user information and login", function(){
		//"to fill in user information and login",
		browser.get("http://team.binary-studio.com/auth/#/");
		//fill in login
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_d@example.com");
		//fill in password
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		//press Login button
		var loginButton = element(by.cssContainingText(".btn", "Log in"));
		loginButton.click()
		console.log("Hello");
	})
	it("like news", function(){
		var num
		element(by.css('[ng-click="newsCtrl.newsLike(news)"]')).getText().then(function(text){
			console.log(text);
			//num = parseInt(text);
			//console.log(num);
			element(by.css(".likes-count-2")).click();
			expect(element(by.css('[ng-click="newsCtrl.newsLike(news)"]')).getText()).toBe(text);
		});
		
	})
	it ("users should be able to logout", function(){
		//afterEach (function(){
			//press on user profile
			
			expect(element(by.id("userProfile")).isDisplayed()).toBeTruthy();
			var logoutBox = browser.findElement(by.id("userProfile"));
			logoutBox.click();
			
			//"to find logout button"
		expect(element(by.id("logOutButton")).isDisplayed()).toBeTruthy();
			var logoutButton = browser.findElement(by.id("logOutButton"));
			logoutButton.click();
			console.log("bye-bye");
	})
})