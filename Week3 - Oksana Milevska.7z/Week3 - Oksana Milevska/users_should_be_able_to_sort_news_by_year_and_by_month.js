describe("sort news by year", function(){

	it ("to fill in user information and login", function(){
		//"to fill in user information and login",
		browser.get("http://team.binary-studio.com/auth/#/");
		//fill in login
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_d@example.com");
		//fill in password
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		//press Login button
		var loginButton = element(by.cssContainingText(".btn", "Log in"));
		loginButton.click()
		console.log("Hello");
	})

	
		it ("select year", function() {
			var yearList;
			//click on year to get yearList
			element(by.id("select_20")).click();
			console.log("click on year selection");
			// count years
			var yearList = element.all(by.repeater("year in newsCtrl.filterYears"));
			expect(yearList.count()).toEqual(2);
			//select 2016
			yearList.get(0).click();
			console.log("select 2016")
			
			var chooseYear16 = browser.findElement(by.id("select_value_label_18"))
			expect(chooseYear16.getText()).toEqual("2016")
			
		});
	
		
		it('sort by month (choose january)', function() {
			//click on month to get monthList
			element(by.id("select_34")).click();
			
			console.log("click on month to show dropdown list")
			
			//click to select month in dropdown list
			element(by.id("select_option_29")).click();
			console.log("select month")
		
		});
		
		it ("check date", function(){
			//verify list of search results
			console.log("check if listed posts has selected data");
			var tookDate = element(by.cssContainingText(".date-2", ""));
			expect(tookDate.getText()).toContain("2016")
		})

	describe("users should be able to logout", function(){
	it ("to find logout button",function(){
		//press on user profile
		var logoutBox = browser.findElement(by.id("userProfile"));
		logoutBox.click();
		//"to find logout button"
		var logoutButton = browser.findElement(by.id("logOutButton"));
		logoutButton.click();
			console.log("bye-bye");
	})
})
})