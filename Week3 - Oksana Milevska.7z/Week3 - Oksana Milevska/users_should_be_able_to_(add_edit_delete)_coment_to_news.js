describe("users should be able to login", function(){
	it ("to fill in user information and login", function(){
		//"to fill in user information and login",
		browser.get("http://team.binary-studio.com/auth/#/");
		//fill in login
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_d@example.com");
		//fill in password
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		//press Login button
		var loginButton = element(by.cssContainingText(".btn", "Log in"));
		loginButton.click()
		console.log("Hello");
	})

	
	it ("add text comment", function(){
		//go to comments
		expect(element(by.cssContainingText(".comments-count-2", "comments")).isDisplayed()).toBeTruthy();
		element(by.cssContainingText(".comments-count-2", "comments")).click();
		console.log("click on comments");
		//click on New comment
		expect(element(by.cssContainingText(".news-input-cover", "Write new comment")).isDisplayed()).toBeTruthy();
		element(by.cssContainingText(".news-input-cover", "Write new comment")).click();
		console.log("click on 'Write new comment'");
		//fill in text
		expect(element(by.id("ui-tinymce-0_ifr")).isDisplayed()).toBeTruthy();
		element(by.id("ui-tinymce-0_ifr")).sendKeys("Here we add new comment");
		console.log("fill in text");
		//seve comment
		//expect(element(by.cssContainingText(".md-button", "Add comment")).isDisplayed()).toBeTruthy();
		element(by.cssContainingText(".md-button", "Add comment")).click();
		console.log("press button'Add comment'");
	})
	
	it ("to edit comment on 'News'", function(){
		//move mouse to buttons
		var text = "we edit "
		//element(by.cssContainingText(".comments-count-2", "comments")).click();
		browser.actions().mouseMove(element(by.xpath('//*[@id="company"]/div[2]/div/div[6]/div[1]'))).perform();
		console.log("buttons become visibile");
		//press edit button
		expect(element(by.css('[ng-click="newsCtrl.setEditing(comment, news._id)"]')).isDisplayed()).toBeTruthy();
		element(by.css('[ng-click="newsCtrl.setEditing(comment, news._id)"]')).click();
		console.log("press edit button");
		//edit comment
		element(by.css('#ui-tinymce-1_ifr')).sendKeys(text);
		element(by.cssContainingText(".md-button", "Save comment")).click();
		console.log("edit text");
	})
	
	it ("to delete comment on 'News'", function(){
		//move mouse to buttons
		//element(by.cssContainingText(".comments-count-2", "comments")).click();
		browser.actions().mouseMove(element(by.xpath(".//*[@id='company']/div[2]/div/div[6]/div[1]"))).perform();
		console.log("buttons become visibile");
		//delete comment
		element(by.xpath(".//*[@id='company']/div[2]/div/div[6]/div[1]/div/div[2]/span[2]/i[2]")).click();
		//browser.actions().sendKeys(protractor.Key.DELETE).perform();
		console.log("press delete button, and delete comment");
			
	})
	
	
	
	
	describe("users should be able to logout", function(){
	it ("users should be able to logout", function(){
		//afterEach (function(){
			//press on user profile
			
			expect(element(by.id("userProfile")).isDisplayed()).toBeTruthy();
			var logoutBox = browser.findElement(by.id("userProfile"));
			logoutBox.click();
			
			//"to find logout button"
		expect(element(by.id("logOutButton")).isDisplayed()).toBeTruthy();
			var logoutButton = browser.findElement(by.id("logOutButton"));
			logoutButton.click();
			console.log("bye-bye");
	})

})
})