describe("sort news by year", function(){

	it ("to fill in user information and login", function(){
		//"to fill in user information and login",
		browser.get("http://team.binary-studio.com/auth/#/");
		//fill in login
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_d@example.com");
		//fill in password
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		//press Login button
		var loginButton = element(by.cssContainingText(".btn", "Log in"));
		loginButton.click()
		console.log("Hello");
	})
		
	it("like news comment in 'Weeklies'", function(){
		
		var text1;
		//go to Weeklies
		element(by.cssContainingText(".md-tab", "Weeklies")).click();
		console.log("go to Weeklies");
		
		//go to comments
		expect(element(by.cssContainingText(".comments-count-2", "comments")).isDisplayed()).toBeTruthy();
		element(by.cssContainingText(".comments-count-2", "comments")).click();
		console.log("go to Comments");
		
		//like and verify number of likes
		element(by.css(".footer-2")).$('.likes-count-2').click();
		expect(element(by.css(".footer-2")).$('.likes-count-2').getText()).not.toContain('1');
		
		
	})
	
	it ("users should be able to logout", function(){
		//afterEach (function(){
			//press on user profile
			
			expect(element(by.id("userProfile")).isDisplayed()).toBeTruthy();
			var logoutBox = browser.findElement(by.id("userProfile"));
			logoutBox.click();
			
			//"to find logout button"
		expect(element(by.id("logOutButton")).isDisplayed()).toBeTruthy();
			var logoutButton = browser.findElement(by.id("logOutButton"));
			logoutButton.click();
			console.log("bye-bye");
	})
})