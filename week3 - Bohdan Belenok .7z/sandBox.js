
describe('Main SandBox functionality', function() {

	var insertLinkButton,insertImageButton,insertVideoButton
	browser.driver.manage().window().maximize();
	
	it('Login test', function() {
	    browser.get('http://team.binary-studio.com/#/sandbox');
	 	element(by.model("authLoginCtrl.user.email")).sendKeys("tester_f@example.com");
	  	element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
	  	element(by.buttonText("Log in")).click();
	  	browser.sleep(2000);

	  	
	   	browser.get('http://team.binary-studio.com/#/sandbox');
		insertLinkButton  = element(by.css('[aria-label="Insert/edit link"]'));
		insertImageButton = element(by.css('[aria-label="Insert/edit image"]'));
		insertVideoButton = element(by.css('[aria-label="Insert/edit video"]'));
    });


	it("Insert Link",function(){
		insertLinkButton.click();
		element.all(by.css(".mce-textbox")).then(function(linKinputs){							//Select and fill in all input fields on link insertion page
		for(i in linKinputs)
		    linKinputs[i].sendKeys("http://team.binary-studio.com/auth/#/");
		element(by.buttonText('Ok')).click();													
	
	    });
	});

	it("Insert Picture",function(){
		insertImageButton.click();
		element(by.css(".mce-textbox"))
		.sendKeys("https://s.dou.ua/storage-files/a118b58423241b0c54b819170b04fe97.gif"); 								//picture source field
		element(by.buttonText('Ok')).click();
	});

	it("Insert Video",function(){
		insertVideoButton.click();
		element(by.css(".mce-textbox")).sendKeys("https://www.youtube.com/watch?v=idb6hOxlyb8"); 						//video source field
		element(by.buttonText('Ok')).click();
		element(by.css('[aria-label="Create post"]')).click();
	});
	

	it("Edit post",function(){
		browser.get('http://team.binary-studio.com/#/sandbox');
		browser.sleep(200);
		var oldSearchStr = "http://team.binary-studio.com/auth/#/http://team.binary-studio.com/auth/#/"; //Search value its values of linkInputs[0] + linkInputs[1]
		var newSearchStr = "`````"																		 //Text after editing
		var searchField  = element(by.model("newsCtrl.newsFilter"));									 //Search field

		/*Search all posts with newSearchStr and count them into newPostsCount*/
		searchField.sendKeys(newSearchStr);																
		browser.sleep(200);  
		var newPostsCount = element.all(by.repeater('news in sboxCtrl.posts')).count();
		expect(newPostsCount).toEqual(0);
		searchField.clear();
		/*-----------------------------------------------------------------------------------------------*/

		/*Search all posts with oldSearchStr and count them into oldPostsCount*/
		searchField.sendKeys(oldSearchStr);   
		var oldPostsCount = element.all(by.repeater('news in sboxCtrl.posts')).count();
		/*-----------------------------------------------------------------------------------------------*/
		expect(oldPostsCount).toBeGreaterThan(0)
		browser.actions().mouseMove(element(by.css('.section'))).perform();
		element(by.css(".fa-pencil")).click();															 //Click Edit

		/*Edit our post and save ------------------------------------------------------------------------*/
   		browser.ignoreSynchronization = true;															
   		browser.switchTo().frame('ui-tinymce-1_ifr');													//text frame
  		var frameTextField = browser.findElement(by.id("tinymce")); 
   	 	frameTextField.clear();
   	 	frameTextField.sendKeys("`````");
   	 	browser.switchTo().defaultContent();
   	 	element(by.css('[aria-label="Save"]')).click();
   	 	/*-----------------------------------------------------------------------------------------------*/

   	 	searchField.clear();
   	 	browser.sleep(200);  
   	 	searchField.sendKeys(newSearchStr);
   	 	browser.sleep(200);  
   	 	expect(element.all(by.repeater('news in sboxCtrl.posts')).count())								//Check posts count wich contain newSearchStr
   	 	.toBeGreaterThan(newPostsCount);																//Should be = newPostsCount + 1 
   	 	searchField.clear();
   	 																									 
   	 	searchField.sendKeys(oldSearchStr);																	 										
   	 	expect(element.all(by.repeater('news in sboxCtrl.posts')).count())								//Check posts count wich contain oldSearchStr
   	 	.toBeLessThan(oldPostsCount); 																	//Should be = oldPostsCount - 1 
   	 	searchField.clear();
	
	});

	it('delete post',function(){
		browser.get('http://team.binary-studio.com/#/sandbox');
		browser.sleep(200);
		var searchStr = "http://team.binary-studio.com/auth/#/http://team.binary-studio.com/auth/#/";  //search value its values of linkInputs[0] + linkInputs[1]
		var searchField = element(by.model("newsCtrl.newsFilter"));
		searchField.sendKeys(searchStr);   							
	 	var postsCount = element.all(by.repeater("news in sboxCtrl.posts")).count();  	      	       //current number of posts
		browser.actions().mouseMove(element(by.css('.section'))).perform();
		element(by.css(".fa-times")).click();
	 	var deleteButton = element(by.css('[ng-click="dialog.hide()"]'));								//Delete button
	 	deleteButton.click();
	 	searchField.clear();
	 	searchField.sendKeys(searchStr);
		expect(element.all(by.repeater("news in sboxCtrl.posts")).count()).toBeLessThan(postsCount);  //Check number of posts wich contain searchStr 
	 });																							  //Should be = postsCount - 1 
});