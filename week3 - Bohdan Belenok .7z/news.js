describe('check filtering by text, Year and Month', function() {

    it('Login test', function() {
	    browser.get('http://team.binary-studio.com/auth/#/');
	 	element(by.model("authLoginCtrl.user.email")).sendKeys("tester_f@example.com");
	  	element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
	  	element(by.buttonText("Log in")).click();	
    });

	it ("Searching by text",function(){
		element(by.model("newsCtrl.newsFilter")).sendKeys("Christmas card");  								//search field
		element.all(by.css('div.news-title-2')).then(function(newsTitles){	
		for( i in newsTitles ){
			expect(newsTitles[i].getText()).toContain("Christmas card");			
		}});
		element(by.model("newsCtrl.newsFilter")).clear();									   				//Clear search field
	});

	it('Chose Another Year on search field', function() {
		element(by.id('select_value_label_18')).click();													//Year selection list
		element(by.id('select_option_37')).click();															//choose 2015
	});

	it("Chose Another Month on search field", function(){     										
	 	var select = element(by.model('newsCtrl.filterMonth'));												//Month selection list 		             											
	 	select.sendKeys("December");																		//Choose December
		element.all(by.className('date-2')).then(function(items){											//Check all dates on posts
   			for( i = 0 ; i < items.length; i++)
   			expect(items[i].getText()).toContain('Dec-2015');
		});
     });

	it('Like and dislike some post', function(){
			var likeItem = element(by.css('[ng-click="newsCtrl.newsLike(news)"]'));
			var likesCount =likeItem.getText();
			likeItem.click();
			expect(likeItem.getText()).toBeGreaterThan(likesCount);
			likeItem.click();
			browser.sleep(2000);
			expect(likeItem.getText()).toEqual(likesCount);
	});
});

describe('comments manipulation',function(){
	var showCommentsButton = element(by.css ('[ng-click="showComments=!showComments"]'));				//open comments button
		
	it('Create comment', function() {

			showCommentsButton.click();
			browser.ignoreSynchronization = true;
			element(by.className('news-input-cover')).click();												//Open input text frame									
			browser.sleep(2000);																			//Wait for frame
	   		browser.switchTo().frame(0);
	   		var frameTextField = browser.findElement(by.id("tinymce"));
	   		frameTextField.sendKeys("newPod");																//Fill in textarea 
	   		browser.switchTo().defaultContent();
	   		element(by.css('[aria-label="Add comment"]')).click();											//Press add commentary
			browser.wait(function() {
	   			return element(by.repeater('comment in news.comments')).isPresent();						//wait for new comment
				}, 5000);
			//expect(element(by.repeater('comment in news.comments')).getText()).toContain("newPod");  //new comentary Should contain 'input value' 
	});

	it('Edit comment',function(){
			browser.refresh();

	  		browser.wait(function() {
	   			return showCommentsButton.isPresent();
				}, 5000);


			showCommentsButton.click();
			browser.ignoreSynchronization = true;
	  		

	  		browser.wait(function() {
	   			return element(by.className('fa-pencil')).isPresent();
				}, 5000);

			
		 	browser.actions().mouseMove(element(by.repeater("comment in news.comments | reverse"))).perform();	 
			element(by.css(".fa-pencil")).click();																//Press edit comment
			browser.sleep(2000);																				//Wait for frame			
			browser.switchTo().frame(0);																			
			var frameTextField = browser.findElement(by.id("tinymce"));
			
			frameTextField.clear();																				
			
	   		frameTextField.sendKeys("PIKACHUUUUUUUUU!!!");														//new input value
	   		browser.switchTo().defaultContent();
	   		element(by.css('[aria-label="Save comment"]')).click();
	   		expect(element(by.repeater('comment in news.comments')).getText())
	   		.toContain("PIKACHUUUUUUUUU!!!");  																	//new comentary should contain 'new input value'
   	});	

	it('like comments,function(){
			var likeItem = element(by.css('[ng-click="newsCtrl.commentLike(news, comment)"]'));					/*Item containe like button and like count*/
			likeItem.click();

			browser.wait(function() {																			//Wait for updating info about likes
	   			return element(by.css('[ng-if="newsCtrl.findLike(comment.likes)"]')).isPresent();
				}, 5000);	

			var likesCount =likeItem.getText();
			expect(likeItem.getText()).toEqual('1');															//Like count check (should be 1)
	});

	it('dislike comment',function(){
			browser.refresh();

	  		browser.wait(function() {
	   			return showCommentsButton.isPresent();
				}, 5000);

	  		showCommentsButton.click();
			var likeItem = element(by.css('[ng-click="newsCtrl.commentLike(news, comment)"]'));
			likeItem.click();


			browser.wait(function() {
	   			return element(by.css('[ng-if="!newsCtrl.findLike(comment.likes)"]')).isPresent();
				}, 5000);	

			browser.sleep(2000);
			var likesCount = likeItem.getText();
			expect(likeItem.getText()).toEqual('0');														//Like count check (should be 0)
	});

	it('Delete comment',function(){
			browser.refresh();
			browser.wait(function() {
	   			return showCommentsButton.isPresent();
				}, 5000);

			showCommentsButton.click();

			 browser.wait(function() {
	   			return element(by.className('fa-times')).isPresent();
				}, 5000);
			browser.actions().mouseMove(element(by.repeater("comment in news.comments | reverse"))).perform();
	 		element(by.css(".fa-times")).click();	 	
	});

 });